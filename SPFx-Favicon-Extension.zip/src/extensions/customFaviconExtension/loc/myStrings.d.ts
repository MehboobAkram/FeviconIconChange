declare interface ICustomFaviconExtensionApplicationCustomizerStrings {
  Title: string;
}

declare module 'CustomFaviconExtensionApplicationCustomizerStrings' {
  const strings: ICustomFaviconExtensionApplicationCustomizerStrings;
  export = strings;
}
