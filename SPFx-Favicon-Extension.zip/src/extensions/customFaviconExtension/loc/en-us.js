define([], function() {
  return {
    "Title": "CustomFaviconExtensionApplicationCustomizer"
  }
});