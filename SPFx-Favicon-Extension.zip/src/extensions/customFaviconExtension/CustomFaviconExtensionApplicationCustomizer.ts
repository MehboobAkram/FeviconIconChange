import { override } from "@microsoft/decorators";
//import { Log } from '@microsoft/sp-core-library';
import { BaseApplicationCustomizer } from "@microsoft/sp-application-base";

//const LOG_SOURCE: string = 'CustomFaviconApplicationCustomizer';

export default class CustomFaviconApplicationCustomizer extends BaseApplicationCustomizer<{}> {
  @override
  public onInit(): Promise<void> {
    try {
      // Commenting out log to avoid any console alerts
      // Log.info(LOG_SOURCE, `Initialized Custom Favicon Application Customizer`);

      this._changeFavicon(
        "https://7xk12j.sharepoint.com/sites/SPFxTraining/Logo/uptitude_ltd_logo.jpeg"
      ); // Replace with your favicon URL
    } catch (error) {
      // Silently handle errors to avoid alerts
      console.error("Error changing favicon:", error);
    }

    return Promise.resolve();
  }

  private _changeFavicon(faviconUrl: string): void {
    try {
      let link: HTMLLinkElement | null =
        document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement("link");
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = faviconUrl;
    } catch (error) {
      console.error("Error updating favicon:", error);
    }
  }
}
