import { BaseApplicationCustomizer } from "@microsoft/sp-application-base";
export default class CustomFaviconApplicationCustomizer extends BaseApplicationCustomizer<{}> {
    onInit(): Promise<void>;
    private _changeFavicon;
}
//# sourceMappingURL=CustomFaviconExtensionApplicationCustomizer.d.ts.map